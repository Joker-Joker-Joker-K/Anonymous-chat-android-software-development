package com.hyphenate.chatdemo.common.enums;

public enum Status {
    SUCCESS,
    ERROR,
    LOADING
}
