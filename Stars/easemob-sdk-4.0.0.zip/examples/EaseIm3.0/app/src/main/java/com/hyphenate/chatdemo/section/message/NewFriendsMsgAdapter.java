package com.hyphenate.chatdemo.section.message;

import com.hyphenate.chat.EMMessage;
import com.hyphenate.easeui.adapter.EaseBaseDelegateAdapter;

public class NewFriendsMsgAdapter extends EaseBaseDelegateAdapter<EMMessage> {

}
