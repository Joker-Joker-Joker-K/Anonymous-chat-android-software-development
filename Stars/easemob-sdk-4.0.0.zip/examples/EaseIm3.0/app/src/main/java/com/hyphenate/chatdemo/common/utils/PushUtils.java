package com.hyphenate.chatdemo.common.utils;

/**
 * 收到推送是否为音视频通话推送
 */
public class PushUtils {
    public static boolean isRtcCall = false;
    public static int type = 0;
}
