package com.hyphenate.chatdemo.section.discover;

import com.hyphenate.chatdemo.R;
import com.hyphenate.chatdemo.section.base.BaseInitFragment;

public class DiscoverFragment extends BaseInitFragment {

    @Override
    protected int getLayoutId() {
        return R.layout.demo_fragment_discover;
    }

}
