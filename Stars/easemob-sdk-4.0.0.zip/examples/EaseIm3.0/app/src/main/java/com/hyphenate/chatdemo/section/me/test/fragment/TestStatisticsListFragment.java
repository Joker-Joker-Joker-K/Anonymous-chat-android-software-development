package com.hyphenate.chatdemo.section.me.test.fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.hyphenate.chatdemo.section.base.BaseInitFragment;

public class TestStatisticsListFragment extends BaseInitFragment {
    @Override
    protected View getLayoutView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container) {
        return super.getLayoutView(inflater, container);
    }
}
