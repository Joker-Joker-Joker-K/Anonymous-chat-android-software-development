package com.hyphenate.chatdemo.section.base;

public abstract class BaseLoginActivity extends BaseInitActivity {

}
